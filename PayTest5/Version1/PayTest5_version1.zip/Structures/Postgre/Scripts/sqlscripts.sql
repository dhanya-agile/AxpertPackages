<<
INSERT INTO axpages (name,caption,props,blobno,img,visible,type,parent,ordno,levelno,updatedon,createdon,importedon,createdby,updatedby,importedby,readonly,updusername,category,pagetype,intview,webenable,shortcut,icon,websubtype,workflow,oldappurl) VALUES ('HP1791202892639','Payroll Page','htmlPages.aspx?load=1791202892639',1,NULL,'T','p',NULL,(SELECT COALESCE(MAX(ordno),0) + 1 FROM axpages),0,'05/10/2026 5:45:29 PM','05/10/2026 5:45:29 PM',NULL,'karthik','karthik',NULL,NULL,NULL,NULL,'web',NULL,NULL,NULL,NULL,'htmlpage',NULL,NULL);INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','adxconfv','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','adxinlog','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','adxoutlo','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','agspr','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','applogsm','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','appsr','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','astcp','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','auditlog','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axchtdtl','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axctx','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axemllog','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axfinyrs','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axglo','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axmme','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axnxtlst','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axroles','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axstc','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axusers','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','axusracc','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','cerrm','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','dmlscrpt','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','esmsco','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head14','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head16','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head160998','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head17','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head18','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head19','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head20','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head21','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head22','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head23','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head249013','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Head929038','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','iaxex','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','iaxpscon','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','iconf','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','idsco','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','ikywd','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','imobc','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','itimtk','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','ivhelpto','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','loview1','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','ofcon','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','Page245','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvadxconfv','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvadxinlog','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvadxoutlo','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvapplogsm','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvauditlog','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvaxchtdtl','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvaxemllog','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvaxfinyrs','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvaxnxtlst','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvaxroles','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvaxusers','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvaxusracc','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvcerrm','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvdmlscrpt','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvesmsco','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIviaxex','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIviaxpscon','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvidsco','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvikywd','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvimobc','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvitimtk','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvivhelpto','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvloview1','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvsmslog','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageIvthint','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsagspr','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsappsr','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsastcp','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsaxctx','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsaxglo','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsaxstc','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsiconf','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsofcon','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTspm','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTssmc','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTstconf','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTstemps','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','PageTsthelp','p',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','pm','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','smc','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','smslog','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','tconf','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','temps','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','thelp','t',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>

<<
INSERT INTO axuseraccess (rname,sname,stype,props,blobno,updatedon,actflag) VALUES ('payroll user','thint','i',NULL,NULL,'05/10/2026 17:57:04',NULL)
>>